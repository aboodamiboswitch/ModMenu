#include <jni.h>
#include <string>
#include <pthread.h>
#include <android/log.h>
#include "Includes/Utils.hpp"
#include "KittyMemory/KittyMemory.hpp"
#include "KittyMemory/MemoryPatch.hpp"

#define TAG "ModMenu"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)

// دالة يتم تشغيلها في الخلفية لتعديل الذاكرة وتطبيق الهاكات
void *hack_thread(void *) {
    LOGI("Mod Menu Thread Started!");
    
    // انتظر حتى يتم تحميل مكتبة اللعبة الأصلية
    uintptr_t libBase = 0;
    while (libBase == 0) {
        libBase = getLibraryAddress("libil2cpp.so");
        sleep(1);
    }
    LOGI("Library base found at: %p", (void*)libBase);

    // حلقة تكرارية مستمرة لفحص تفعيل الخيارات وتطبيق الباتشات
    while (true) {
        // مثال: إذا قمت بتفعيل خيار معين في القائمة، قم بتطبيق الباتش هنا
        // if (g_GodMode) {
        //     MemoryPatch::createWithHex("libil2cpp.so", 0x123456, "00 00 A0 E3").modify();
        // }
        
        sleep(2); // فحص كل ثانيتين لتقليل استهلاك المعالج
    }
    return NULL;
}

// نقطة الاتصال مع واجهة الجافا
extern "C" JNIEXPORT void JNICALL
Java_uk_lgl_modmenu_Preferences_Changes(JNIEnv *env, jclass clazz, jobject context, jint deutsch, jint fff) {
    // دالة استقبال التغييرات من واجهة المود منيو
}

// دالة التشغيل الرئيسية عند حقن المكتبة في اللعبة
JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *env;
    if (vm->GetEnv((void **) &env, JNI_VERSION_1_6) != JNI_OK) {
        return JNI_ERR;
    }

    // تشغيل خيط (Thread) خاص بالهاكات لكي لا يتسبب في تعليق اللعبة
    pthread_t pt;
    pthread_create(&pt, NULL, hack_thread, NULL);

    return JNI_VERSION_1_6;
}
