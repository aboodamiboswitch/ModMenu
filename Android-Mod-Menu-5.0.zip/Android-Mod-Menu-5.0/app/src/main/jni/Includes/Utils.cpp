#include "Includes/Utils.hpp"

uintptr_t getLibraryAddress(const char *libraryName) {
    char filename[0xFF] = {0};
    sprintf(filename, "/data/data/%s/", libraryName); // أو استخدام الطريقة القياسية
    void *handle = dlopen(libraryName, RTLD_NOW);
    if (!handle) {
        return 0;
    }
    Dl_info info;
    if (dladdr(handle, &info) != 0) {
        dlclose(handle);
        return (uintptr_t)info.dli_fbase;
    }
    dlclose(handle);
    return 0;
}

void* getAbsoluteAddress(const char *libraryName, const char *relative) {
    uintptr_t libAddr = getLibraryAddress(libraryName);
    if (libAddr == 0) return 0;
    return (void *)(libAddr + str2offset(relative));
}

bool isLibraryLoaded(const char *libraryName) {
    char line[512] = {0};
    FILE *fp = fopen("/proc/self/maps", "rt");
    if (fp != NULL) {
        while (fgets(line, sizeof(line), fp)) {
            if (strstr(line, libraryName)) {
                fclose(fp);
                return true;
            }
        }
        fclose(fp);
    }
    return false;
}

uintptr_t str2offset(const char *c) {
    return strtoull(c, NULL, 16);
}
