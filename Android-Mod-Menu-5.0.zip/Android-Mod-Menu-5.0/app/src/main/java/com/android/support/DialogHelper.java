package com.android.support;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

public class DialogHelper {

    public static void showDialogWithLink(final Context context, String title, String message, String LinkBtnTitle, String CloseBtnTitle, int sec, final String url) {
        if (context instanceof Activity) {
            Activity activity = (Activity) context;
            if (activity.isFinishing() || activity.isDestroyed()) {
                return;
            }
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(context)
                .setTitle(title)
                .setMessage(message);

        if (url != null && !url.trim().isEmpty()) {
            builder.setPositiveButton(LinkBtnTitle, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    openUrlSafely(context, url);
                }
            });
        }

        String closeInitTitle = CloseBtnTitle;
        if (sec > 0) {
            closeInitTitle = closeInitTitle + " (" + sec + ")";
        }

        builder.setNegativeButton(closeInitTitle, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        final AlertDialog dialog = builder.create();
        dialog.show();

        if (sec > 0) {
            startCountdown(dialog, CloseBtnTitle, sec);
        }
    }

    private static void startCountdown(final AlertDialog dialog, final String closeBtnTitle, final int seconds) {
        final Handler handler = new Handler(Looper.getMainLooper());
        final Runnable countdownRunnable = new Runnable() {
            int remainingTime = seconds;

            @SuppressLint("SetTextI18n")
            @Override
            public void run() {
                if (dialog == null || !dialog.isShowing()) {
                    return;
                }

                if (remainingTime > 0) {
                    android.widget.Button negativeButton = dialog.getButton(AlertDialog.BUTTON_NEGATIVE);
                    if (negativeButton != null) {
                        negativeButton.setText(closeBtnTitle + " (" + remainingTime + ")");
                    }
                    remainingTime--;
                    handler.postDelayed(this, 1000);
                } else {
                    try {
                        dialog.dismiss();
                    } catch (Exception e) {
                        // تجاهل الاستثناء
                    }
                }
            }
        };

        handler.postDelayed(countdownRunnable, 1000);

        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {
                handler.removeCallbacks(countdownRunnable);
            }
        });
    }

    @SuppressLint("QueryPermissionsNeeded")
    public static void openUrlSafely(Context context, String url) {
        if (url == null || url.trim().isEmpty()) {
            return;
        }

        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            url = "http://" + url;
        }

        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

            if (intent.resolveActivity(context.getPackageManager()) != null) {
                context.startActivity(intent);
            } else {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                browserIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                browserIntent.setPackage("com.android.chrome");

                if (browserIntent.resolveActivity(context.getPackageManager()) != null) {
                    context.startActivity(browserIntent);
                } else {
                    browserIntent.setPackage(null);
                    context.startActivity(browserIntent);
                }
            }
        } catch (Exception e) {
            Toast.makeText(context, "فشل فتح الرابط: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}

